# LINK 

[![portfolio](https://img.shields.io/badge/my_portfolio-1dcf57?style=for-the-badge&logo=ko-fi&logoColor=white)](https://amrit-giri.com.np/)
[![linkedin](https://img.shields.io/badge/linkedin-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white)](/)

[![twitter](https://img.shields.io/badge/twitter-1DA1F2?style=for-the-badge&logo=twitter&logoColor=white)]()
[![YouTube](https://img.shields.io/badge/youtube-ffffff?style=for-the-badge&logo=youtube&logoColor=red)](https://?sub_confirmation=1)
[![GitHub](https://img.shields.io/badge/github-ffffff?style=for-the-badge&logo=github&logoColor=black)](https://github.com/HKHacker1/)


[![image](https://user-images.githubusercontent.com/85377404/161822288-e91687f5-7d3b-4a96-bbe4-08e01d04cf0d.png)](https://?sub_conformation=1)

[![Build status](https://github.com/termux/termux-app/workflows/Build/badge.svg)](https://github.com/HKHacker1)

# COPYRIGHT

**Copyright Disclaimer Under Section 107 of the Copyright Act 1976, allowance is made for "fair use" for purposes such as criticism, comment, news reporting, teaching, scholarship, and research. Fair use is a use permitted by copyright statute that might otherwise be infringing. Non-profit, educational or personal use tips the balance in favor of fair use. No copyright infringement intended.**

# IT WILL UPGRADE

**AS POSSIBLE UPDATE VERSION WILL COME Soon**

#
REMOVE LOCK FUNCTION
  &
FORGET PASSWORD

``

#

# Termux-Login

**Usage**

This script is for security or lock in termux

# Apps Install
**Hello everyone You can install Termux from F-Drod or given link. You can install from playstore you got an error.So install from ``f-droid`` Given link is below.**

**termux-api install:** https://play.google.com/store/apps/details?id=com.termux.api

**Termux Direct install:** https://f-droid.org/repo/com.termux_118.apk

**F-Droid install:** https://f-droid.org/F-Droid.apk

# Commands

``apt update``

``apt install git ``

``git clone https://github.com/HKHacker1/termux-login.git``

``cd termux-login ``

``chmod +x setup.sh login.sh``

``bash setup.sh``

``bash login.sh``

**Exit and Login To apply changes**

# Note

**If you entered password incorrect or name i can't help you.**
**But Restart your Terminal and ENTER curent Password then login.**

# Contributers

4mrit Giri (only)
